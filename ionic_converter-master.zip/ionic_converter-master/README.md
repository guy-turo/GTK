# Currency Converter

cu-conve is a simple currency Conversion mobile application which is developed by using ionic framework. Ionic framework is a cross platform application development framework widely used by many organizations.

![021Artboard 1@4x](https://user-images.githubusercontent.com/25591638/57977907-81193b00-7a1f-11e9-9bd7-bb5a2b50a49d.png)


## Learning outcomes
- Data binding
- Event binding
- HTTPClient  
- JSON Mapping
- Asynchronous method

